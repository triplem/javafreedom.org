<?php get_header(); ?>

<div id="content">

<div id="contentleft">
	<h1>Not Found, Error 404</h1>
	<p>The page you are looking for no longer exists.</p>
	</div>

<div id="contentright">
	<h1>Recently</h1>
	<ul><?php get_archives('postbypost', 10); ?></ul><br />
	
	<h1>Categories</h1>
	<ul><?php wp_list_cats('sort_column=name'); ?></ul><br />
	
	<h1>Archives</h1>
	<ul><?php wp_get_archives('type=monthly'); ?></ul>
	</div>

</div>
</div>

<!-- The main column ends  -->

<?php get_footer(); ?>