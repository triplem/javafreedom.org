<!-- begin footer -->

<div style="clear:both;"></div>
<div style="clear:both;"></div>

<div id="footerbg">
<div id="footer">

<div id="footerleft">
&nbsp;
</div>


<div id="footermiddle">
<p>Site powered by <a href="http://www.wordpress.org">WordPress</a>.<br />The used Theme is based on <a href="http://www.briangardner.com/themes/vertigo-squared-wordpress-theme.htm" >Vertigo Squared</a> created by <a href="http://www.briangardner.com" >Brian Gardner</a>.</p>
</div>

<div id="footerright">
&nbsp;
</div>
</div>
</div>

<?php do_action('wp_footer'); ?>

</body>
</html>
