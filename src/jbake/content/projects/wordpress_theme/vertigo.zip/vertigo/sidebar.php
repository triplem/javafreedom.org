<div id="contentright">
	<h1>Find It</h1>
   <form id="searchform" method="get" action="<?php echo $_SERVER['PHP_SELF']; ?>">
	<input type="text" name="s" id="s" size="30" value="search this site..."/>
   </form><br />

	<h1>Recently</h1>
	<ul><?php get_archives('postbypost', 10); ?></ul><br />
	
	<h1>Categories</h1>
	<ul><?php wp_list_cats('sort_column=name'); ?></ul><br />
	
	<h1>Archives</h1>
	<ul><?php wp_get_archives('type=monthly'); ?></ul><br />
	
	<h1>Links</h1>
	<ul>
	<?php get_links_list('id'); ?>
	</ul>
<br/>
	<h1>Admin</h1>
	<ul>
	<?php wp_register(); ?>
	<li><?php wp_loginout(); ?></li>
	<li><a href="http://www.wordpress.org/">Wordpress</a></li>
	<?php wp_meta(); ?>
	<li><a href="http://validator.w3.org/check?uri=referer">XHTML</a></li>
	</ul>
</div>
